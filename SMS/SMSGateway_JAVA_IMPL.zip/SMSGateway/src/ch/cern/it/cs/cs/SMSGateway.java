package ch.cern.it.cs.cs;

public class SMSGateway {
	
}

package ch.cern.it.cs.cs.launcher;

import ch.cern.it.cs.cs.display.Display;

public class Launcher {
	
	public static void main(String[] args) {
		new Display();
	}

}
